package mqttPrac;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class Publisher{
 
	private static	String value = "Hello there this is my first mqtt project";

	public static void main(String args[]) throws MqttException {
		MqttClient client = new MqttClient("tcp://localhost:1883",MqttClient.generateClientId());
		client.connect();
		MqttMessage message = new MqttMessage();
		
		message.setPayload(value.getBytes());
		client.publish("getModsimValue", message);
		client.disconnect();
		client.close();
	}
	
	
}
